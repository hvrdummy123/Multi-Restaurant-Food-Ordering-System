package com.example.userService.entity;

public enum Role
{
    ADMIN,
    USER,
    OWNER
}
